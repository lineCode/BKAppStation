package cc.fish.fishhttp.net;

/**
 * Created by fish on 16-4-28.
 */
public class BaseEntity {
    private int code;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
