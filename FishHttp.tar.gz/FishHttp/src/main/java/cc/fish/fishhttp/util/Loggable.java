package cc.fish.fishhttp.util;

/**
 * Created by fish on 17-10-17.
 */

public interface Loggable {
    String toLog();
}
